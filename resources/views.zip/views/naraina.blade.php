<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
    <head>
       
        <meta name="desciption" content="KML Example - MapmyIndia Maps API, kml file upload to display map overlays leaflet ">
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <link rel="icon" href="http://mapmyindia.com/images/favicon.ico" type="image/x-icon">
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
            <link rel="stylesheet" href="{{url('css/bootstrap.css')}}">
        <!--put your map api javascript url with key here-->
        <script src="https://apis.mapmyindia.com/advancedmaps/v1/5klgounjtvu8ih2zfu2fefl63tr9qkl7/map_load?v=1.2"></script>
        
       <link rel="icon" href="http://mapmyindia.com/images/favicon.ico" type="image/x-icon">

                
                <script src="{{url('js/jquery-1.12.3.min.js')}}"></script>
				<script src="https://apis.mapmyindia.com/advancedmaps/v1/5klgounjtvu8ih2zfu2fefl63tr9qkl7/map_load?v=1.2"></script>
               

    </head>
    <body>
         <div class="container">
              <div class="row text-center">
	  <div class="col-sm-12">
        <div class="col-sm-4">
                       
                        
        
		<form action="" method="post">
        <div style="border-bottom: 1px solid #e9e9e9;padding:10px 12px;background:#fff;"><span style="font-size: 20px">WE The Change : </span> <span style="font-size:16px;color:#777">LAP</span>
		</div>
		
                  
            <div id="menu">
              <div style="padding: 0 12px 0 17px;line-height:20px">
			  <div style="padding: 5px 0;font-size:13px;color:#222">Map : Naraina
			 
              <table>
			  <tr>
			             <td style="font-size: 16px;padding: 10px 0px 0px 0px;">Area Boundary : </td><td><button  type="button"  value="Area_Boundary.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
				       </tr><tr>
			             <td style="font-size: 16px;padding: 10px 0px 0px 0px;">ATM : </td><td><button  type="button"  value="ATM_BANKS.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b2f0e8_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Building Plots : </td><td><button  type="button"  value="building_plots.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Bus stop : </td><td><button  type="button"  value="Bus_Stops.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b31718_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Bus Routes : </td><td><button  type="button"  value="Bus_Routes.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Conjested Points  : </td><td><button  type="button"  value="Conjested_Points.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b31138_0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Companies Consultants Offices : </td><td><button  type="button"  value="Companies_Consultants_Offices.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b30110_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Dealers : </td><td><button  type="button"  value="Dealers.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b31138_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Distributive Facilities : </td><td><button  type="button"  value="Distributive_facilities.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b2ef70_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Exporter : </td><td><button  type="button"  value="Exporter.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b30cd0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Green Along Roads : </td><td><button  type="button"  value="Green_along_roads.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					</tr>
					<tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Hotels : </td><td><button  type="button"  value="Hotels.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_197f50a0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Industry : </td><td><button  type="button"  value="Industry.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b306f0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Landuse : </td><td><button  type="button"  value="Landuse.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Manufacturer : </td><td><button  type="button"  value="Manufacturer.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b30110_0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Medical Facilities : </td><td><button  type="button"  value="Medical_Facilities.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_197f6240_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Parking : </td><td><button  type="button"  value="Parking.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b2fb30_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Parks : </td><td><button  type="button"  value="Parks.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">PSP : </td><td><button  type="button"  value="PSP.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b34618_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Public Toilets : </td><td><button  type="button"  value="Public_Toilets.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b312b0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Religious Facilities : </td><td><button  type="button"  value="Religious_facilities.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b315a0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Restaurant : </td><td><button  type="button"  value="restaurant.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b2f260_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Schools : </td><td><button  type="button"  value="schools.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b30e48_0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Services : </td><td><button  type="button"  value="Services.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b2f3d8_0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Shops : </td><td><button  type="button"  value="shops.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b30e48_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Supplier : </td><td><button  type="button"  value="roads.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_12b2fb30_0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Water Tanks : </td><td><button  type="button"  value="Water_Tanks.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_102ef428_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Wellness : </td><td><button  type="button"  value="wellness.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_102ef428_0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Wholesaler : </td><td><button  type="button"  value="Wholesaler.kml" name="aadi" onclick="init(this.value)"  style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file-naraina/Layer0_Symbol_102ef428_0_0.png" style="width:40px;height:40px;"></td>
					</tr>
			  </table>
                
				</div>
                <br>
				
                    </div>
                </div>
              </form> 
              
                        
                    </div>
                    <div class="col-sm-8">
                       
                        <div id="map-container" style="height:1000px;"></div>
                     </div>
                      
    <script type="text/javascript">
            var map_obj=0,kmlLayer=0;
			init('Area_Boundary.kml');
            function init(valu)
            {
                var url = '<?php echo url('kml-file-naraina')?>';
                var kml = url+'/'+valu;
                if(!map_obj) map_obj=new MapmyIndia.Map('map-container',{center:[28.61,77.23],zoomControl: true,hybrid:false,search:false });
                if(kmlLayer) map_obj.removeLayer(kmlLayer);
                kmlLayer=new MapmyIndia.kml(map_obj,kml, {fitBounds:true,async: true});
            }
            function loadFile()
            {
                document.getElementById("text_file").value='Wait..';
                var fileToLoad = document.getElementById("fileToLoad").files[0];
                var fileReader = new FileReader();
                fileReader.onload = function(fileLoadedEvent) 
                {
                    var textFromFileLoaded = fileLoadedEvent.target.result;
                    document.getElementById("text_file").value = textFromFileLoaded;
                    init(textFromFileLoaded);
                };
                fileReader.readAsText(fileToLoad, "UTF-8");
            }
            
        </script>
        </div>
        </div>
                </div>
            </body>
</html>

