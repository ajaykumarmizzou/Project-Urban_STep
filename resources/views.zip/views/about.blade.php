@extends('layouts.app')

@section('content')
    <section class="dt-breadcrumbs">
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ul>
                        <li><a href="{{url('/')}}">Home</a>
                        <li><a href="#">About Us</a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
    <section class="sec2">
        <div class="container-fluid">
            <div class="container">

                <section class="about-us">
                    <div class="container-fluid">
                        <div class="container">
                            <div class="row text-center">
                                <div class="col-sm-12">
                                    <h2 class="cmn-h2">About Us</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="img-bx-pull-right">
                                        <img src="images/image001.jpg" class="img-responsive">
                                    </div>
                                    <p class="text-justify">The School of Planning and Architecture had a modest beginning in 1941 as a Department of Architecture of Delhi Polytechnic. It was later affiliated to the University of Delhi and integrated with the School of Town and Country Planning which was established in 1955 by the Government of India to provide facilities for rural, urban and regional planning. On integration, the School was renamed as School of Planning and Architecture in 1959.<br><br>
                                        Recognizing the specialized nature of the fields in which the School had attained eminence, in 1979, the Government of India, through the then Ministry of Education and Culture, conferred on the School of Planning and Architecture the status of "Deemed to be a University". With this new status, the School had broadened its horizon by introducing new academic and extension programmes and promoting research and consultancy activities. It was recognized as "An Institute of National Importance under an Act of Parliament" in 2015.<br><br>
                                        The School is a specialized University, only one of its kinds, which exclusively provides training at various levels, in different aspects of human habitat and environment. The School has taken lead in introducing academic programmes in specialized fields both at Bachelor's and Master's level, some of which are even today not available elsewhere in India. The School, in striving for excellence, has always been in the lead in extending education and research to new frontiers of knowledge. Human habitat and environment being the basic concern of the School, the spectrum of academic programmes is being continuously extended by providing programmes in new fields and emerging areas for which facilities are not available, as yet, anywhere else in the country.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>

@stop
