<nav class="navbar navbar-default clrylw">
    <div class="container-fluid">
        <div class="container">
            <div class="collapse navbar-collapse ccNav" id="bs-example-navbar-collapse-1">


                    <ul class="nav navbar-nav">
                        <li class="active"><a href="{{url('/')}}"  target="_self" class=""> Home</a></li>
                        <li><a href="{{url('about-us')}}"  target="_self" class=""> About us</a></li>
                        <li><a href="{{url('governance')}}"  target="_self" class=""> Governance</a></li>
                        <li><a href="{{url('ongoing-project')}}"  target="_self" class=""> Ongoing Project</a></li>
                        <li><a href="{{url('contact')}}"  target="_self" class=""> Contact us </a></li>
                        <!--<li><a href="#"><i class="clry">Emergency Contact</i></a></li>-->
                        @if(Auth::guard('web')->id())
                            <li><a href="{{url('/dashboard')}}" >My Account</a></li>
                            <li><a href="{{url('/logout')}}" >Logout</a></li>
                        @else
                            <li><a href="{{url('/login')}}" style="font-size:23px;">LogIn</a></li>
                            <li><a href="#" data-toggle="modal"  data-target="#loginModals" style="font-size:23px;">Register</a></li>
                        @endif
                    </ul>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <ul class="nav navbar-nav navbar-right sci">
                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
</div>
</div>
</div>
</nav>