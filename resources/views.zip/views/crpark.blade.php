<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
    <head>
       
        <meta name="desciption" content="KML Example - MapmyIndia Maps API, kml file upload to display map overlays leaflet ">
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <link rel="icon" href="http://mapmyindia.com/images/favicon.ico" type="image/x-icon">
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
 <link rel="stylesheet" href="{{url('css/bootstrap.css')}}">
        <!--put your map api javascript url with key here-->
        <script src="https://apis.mapmyindia.com/advancedmaps/v1/5klgounjtvu8ih2zfu2fefl63tr9qkl7/map_load?v=1.2"></script>
        
       <link rel="icon" href="http://mapmyindia.com/images/favicon.ico" type="image/x-icon">

                
                <script src="{{url('js/jquery-1.12.3.min.js')}}"></script>
				<script src="https://apis.mapmyindia.com/advancedmaps/v1/5klgounjtvu8ih2zfu2fefl63tr9qkl7/map_load?v=1.2"></script>
               

    </head>
    <body>
	 <div class="container">
              <div class="row text-center">
	  <div class="col-sm-12">
        <div class="col-sm-4">
                       
                        
        
		<form action="" method="post">
        <div style="border-bottom: 1px solid #e9e9e9;padding:10px 12px;background:#fff;"><span style="font-size: 20px">WE The Change : </span> <span style="font-size:16px;color:#777">LAP</span>
		</div>
		
                  
            <div id="menu">
              <div style="padding: 0 12px 0 17px;line-height:20px">
			  <div style="padding: 5px 0;font-size:13px;color:#222">Map : C.R Park</div>
			 
              <table>
			  
			  <tr>
			        <td style="font-size: 16px;padding: 10px 0px 0px 0px;">ATM : </td>
					<td><button value="ATM_bank.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad5430_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Alaknanda BuiltUp : </td><td><button value="Alaknanda_builtup.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Block Name : </td><td><button value="Block_Name.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cacbae0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Boundary : </td><td><button value="Boundary.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Bus Routes : </td><td><button value="Bus_routes.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Bus stop : </td><td><button value="Bus_stop.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad6ea0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Conflict Points : </td><td><button value="conflict_points.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Conflictpoint Buffer : </td><td><button value="conflictpoint_buffer.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Consultants : </td><td><button value="consultants.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">CRPark Builtup : </td><td><button value="CRPark_builtup.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">DDAflats Builtup : </td><td><button value="DDAflats_builtup.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Distributive Facilities : </td><td><button value="Distributive_facilities.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_1.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Education : </td><td><button value="education.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_d5022e0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Green Alongroads : </td><td><button value="green_alongroads.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Hotels : </td><td><button value="Hotels.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_2.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Landuse : </td><td><button value="landuse.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Medical Facilities : </td><td><button value="medical_facilities.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_3.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Offices : </td><td><button value="offices.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_4.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Offstreet Parking : </td><td><button value="offstreet_parking.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Onstreet Parking : </td><td><button value="onstreet_parking.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Public Toilet : </td><td><button value="Public_toilet.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_5.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Public Utilities : </td><td><button value="public_utilities.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_d1e9dd0_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Religious Facilities : </td><td><button value="Religious_facilities.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_6.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Restaurants Cafes : </td><td><button value="Restaurants_cafes.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7018_0_7.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Roads : </td><td><button value="roads.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Water Tanks : </td><td><button value="water_tanks.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_55f7cc8_0.png" style="width:40px;height:40px;"></td>
					</tr><tr>
					<td style="font-size: 16px;padding: 10px 0px 0px 0px;">Wellness : </td><td><button value="wellness.kml" name="aadi" onclick="init(this.value)" type="button" style="margin-top:10px;">View on Map</button></td>
					<td><img src="https://www.fuel4mobi.com/dev/kml-file/Layer0_Symbol_cad7308_0_0.png" style="width:40px;height:40px;"></td>
					</tr>
			  </table>
                
				</div>
                <br>
				
                    </div>
                
              </form> 
                        
                    </div>
                    <div class="col-sm-8">
                       
                        <div id="map-container" style="height:1000px;"></div>
                     </div>
                      <script src="http://apis.mapmyindia.com/advancedmaps/v1/5klgounjtvu8ih2zfu2fefl63tr9qkl7/map_load?v=1.2"></script>
    <script type="text/javascript">
            var map_obj=0,kmlLayer=0;
			init('Boundary.kml');
            function init(valu)
            {
                var url = '<?php echo url('kml-file')?>';
                var kml = url+'/'+valu;
                if(!map_obj) map_obj=new MapmyIndia.Map('map-container',{center:[28.61,77.23],zoomControl: true,hybrid:false,search:false });
                if(kmlLayer) map_obj.removeLayer(kmlLayer);
                kmlLayer=new MapmyIndia.kml(map_obj,kml, {fitBounds:true,async: true});
            }
            function loadFile()
            {
                document.getElementById("text_file").value='Wait..';
                var fileToLoad = document.getElementById("fileToLoad").files[0];
                var fileReader = new FileReader();
                fileReader.onload = function(fileLoadedEvent) 
                {
                    var textFromFileLoaded = fileLoadedEvent.target.result;
                    document.getElementById("text_file").value = textFromFileLoaded;
                    init(textFromFileLoaded);
                };
                fileReader.readAsText(fileToLoad, "UTF-8");
            }
            
        </script>
		  
	    <!--div to show the best result matching the search
                    <br><hr><div class="doc1" >Source Code</div>-->
                    

                    <!--div to show the other result-->
                   <!-- <div style="border-top: 1px solid #e9e9e9;padding:10px; margin-top: 12px" id="otherresult"></div>-->
         
              </div>
        </div>
                </div>  
            </body>
</html>

