@extends('layouts.app')

@section('content')
    <section class="sec2">
        <div class="container-fluid">

    </div>
    </section>

@stop
